import React from "react";
const GeneratedComponent = () => {
  return (
    <div
      id="_3478_265_2_3-fill"
      style={{
        position: "absolute",
        overflow: "hidden",
        background: "rgba(9, 8, 12, 1.00)",
        height: "100vh",
        width: "100%",
      }}
    >
      <div
        id="_3792_6056_2_3"
        style={{
          position: "absolute",
          background:
            "url(assets/images/f01c2b59dcaa91cb6f2b03af29681cd23d0a4774) 100% / cover no-repeat",
          height: "900.0px",
          width: "1440.0px",
          left: "0.0px",
          top: "0.0px",
        }}
      ></div>
    </div>
  );
};

export default GeneratedComponent;
