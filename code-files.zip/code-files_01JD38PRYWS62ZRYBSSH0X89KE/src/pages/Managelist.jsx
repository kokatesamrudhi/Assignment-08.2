import { useNavigate } from "react-router-dom";
import React from "react";
const GeneratedComponent = () => {
  const navigate = useNavigate();
  return (
    <div
      id="_3450_119_2_2_3-manage-list"
      onClick={() => navigate("/Managetoken")}
      style={{
        position: "absolute",
        overflow: "hidden",
        background: "rgba(9, 8, 12, 1.00)",
        height: "100vh",
        width: "100%",
        cursor: "pointer",
      }}
    >
      <div
        id="_3792_6054_2_2_3"
        style={{
          position: "absolute",
          background:
            "url(assets/images/9a07563a394d9827e54e670aa8719345b032d842) 100% / cover no-repeat",
          height: "900.0px",
          width: "1440.0px",
          left: "0.0px",
          top: "0.0px",
        }}
      ></div>
    </div>
  );
};

export default GeneratedComponent;
