import React from "react";
const GeneratedComponent = () => {
  return (
    <div
      id="_3428_57797_2_2-select-a-token"
      style={{
        position: "absolute",
        overflow: "hidden",
        background: "rgba(9, 8, 12, 1.00)",
        height: "100vh",
        width: "100%",
      }}
    >
      <div
        id="_3792_6051_2_2"
        style={{
          position: "absolute",
          background:
            "url(assets/images/a4b564b175ffa6361f78e1eadb7518a2117f1d91) 100% / cover no-repeat",
          height: "900.0px",
          width: "1440.0px",
          left: "0.0px",
          top: "0.0px",
        }}
      ></div>
    </div>
  );
};

export default GeneratedComponent;
