import React from "react";
const GeneratedComponent = () => {
  return (
    <div
      id="_3402_52562_1_1-connect-wallet"
      style={{
        position: "absolute",
        overflow: "hidden",
        background: "rgba(9, 8, 12, 1.00)",
        height: "100vh",
        width: "100%",
      }}
    >
      <img
        id="_3588"
        src="assets/images/240211666768.svg"
        alt="under"
        style={{
          position: "absolute",
          left: "calc(100% * -3.947459643111668E-17)",
        }}
      />
      <div
        id="_3402_52640_mask"
        style={{
          position: "absolute",
          background: "rgba(32, 29, 41, 0.72)",
          backdropFilter: "blur(8.0px)",
          height: "900.0px",
          width: "1440.0px",
          left: "0.0px",
          top: "0.0px",
        }}
      ></div>

      <img
        id="_3420_"
        src="assets/images/183795901312.svg"
        alt="pop-up"
        style={{
          position: "absolute",
          left: "calc(100% * 0.3388888888888889)",
          top: "calc(100% * 0.18666666666666668)",
        }}
      />
    </div>
  );
};

export default GeneratedComponent;
