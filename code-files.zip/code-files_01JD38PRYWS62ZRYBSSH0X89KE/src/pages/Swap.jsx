import React from "react";
const GeneratedComponent = () => {
  return (
    <div
      id="_3428_51035_2-swap"
      style={{
        position: "absolute",
        overflow: "hidden",
        background: "rgba(9, 8, 12, 1.00)",
        height: "100vh",
        width: "100%",
      }}
    >
      <div
        id="_3792_6045_2-swap_1"
        onClick="history.back()"
        style={{
          position: "absolute",
          background:
            "url(assets/images/7daaeeeed4c114758c7ffdfbfc95d0640c3885c8) 100% / cover no-repeat",
          height: "900.0px",
          width: "1440.0px",
          left: "0.0px",
          top: "0.0px",
          cursor: "pointer",
        }}
      ></div>
    </div>
  );
};

export default GeneratedComponent;
