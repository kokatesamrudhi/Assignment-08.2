import React from "react";
const GeneratedComponent = () => {
  return (
    <div
      id="_3486_54262_2_6-transaction"
      style={{
        position: "absolute",
        overflow: "hidden",
        background: "rgba(9, 8, 12, 1.00)",
        height: "100vh",
        width: "100%",
      }}
    >
      <div
        id="_3792_6059_2_4_2"
        onClick="history.back()"
        style={{
          position: "absolute",
          background:
            "url(assets/images/54d0076f78708982da886949c1e35fc86cc3722b) 100% / cover no-repeat",
          height: "900.0px",
          width: "1440.0px",
          left: "0.0px",
          top: "0.0px",
          cursor: "pointer",
        }}
      ></div>
    </div>
  );
};

export default GeneratedComponent;
