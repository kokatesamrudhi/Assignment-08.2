import React from "react";
const GeneratedComponent = () => {
  return (
    <div
      id="_3476_0_2_2_4-manage-token"
      style={{
        position: "absolute",
        overflow: "hidden",
        background: "rgba(9, 8, 12, 1.00)",
        height: "100vh",
        width: "100%",
      }}
    >
      <div
        id="_3792_6055_2_2_4"
        style={{
          position: "absolute",
          background:
            "url(assets/images/29d04b1b52feb9d5be065eb62b994e4d267064da) 100% / cover no-repeat",
          height: "900.0px",
          width: "1440.0px",
          left: "0.0px",
          top: "0.0px",
        }}
      ></div>
    </div>
  );
};

export default GeneratedComponent;
